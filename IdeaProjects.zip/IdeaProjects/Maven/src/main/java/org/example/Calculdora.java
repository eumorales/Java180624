package org.example;

public class Calculdora {

    private float x;
    private float y;

    float resultado;

    public float getX() {
        return x;
    }

    public void setX(float x) {
        this.x = x;
    }

    public float getY() {
        return y;
    }

    public void setY(float y) {
        this.y = y;
    }

    public float soma() {

        resultado = x + y;
        System.out.println("Soma: " + resultado);

        return resultado;
    }

    public float sub() {
        resultado = x - y;
        System.out.println("Subtração: " + resultado);

        return resultado;
    }

    public float mult() {
        resultado = x * y;
        System.out.println("Multiplicação: " + resultado);

        return resultado;
    }

    public void div() {
        if (y != 0) {
            float resultado = x / y;
            System.out.println("Divisão: " + resultado);
        } else {
            System.out.println("A divisão não pode ser por zero.");
        }
    }
    public void raiz() {
        if (x >= 0) {
            double resultado = Math.sqrt(x);
            System.out.println("Raiz quadrada de " + x + ": " + resultado);
        } else {
            System.out.println("Não é possível calcular raiz de um número negativo.");
        }
    }


    public void potencia() {
        double resultado = Math.pow(x, y);
        System.out.println(x + " elevado a " + y + ": " + resultado);
    }




}
