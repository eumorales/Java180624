package org.example;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CalculadoraTeste {

    // Soma

    @Test
    void somaDois() {
        var calculadora = new Calculadora();
        calculadora.setX(2);
        calculadora.setY(2);
        assertEquals(4, calculadora.soma());
    }

    @Test
    void somaDoisPontoCinco() {
        var calculadora = new Calculadora();
        calculadora.setX(2.5);
        calculadora.setY(2.5);
        assertEquals(5.0, calculadora.soma());
    }

    @Test
    void somaDoisEMenosCinco() {
        var calculadora = new Calculadora();
        calculadora.setX(2);
        calculadora.setY(-5);
        assertEquals(-3, calculadora.soma());
    }

    @Test
    void somaDezEDoisPontoCinco() {
        var calculadora = new Calculadora();
        calculadora.setX(10);
        calculadora.setY(2.5);
        assertEquals(12.5, calculadora.soma());
    }
}
